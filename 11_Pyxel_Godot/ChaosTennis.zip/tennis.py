import pyxel
import math
import random

# --- 定数管理 ---
class Config:
    SCREEN_WIDTH = 160
    SCREEN_HEIGHT = 120
    PADDLE_WIDTH = 4
    PADDLE_HEIGHT = 20
    BALL_SIZE = 3
    
    COLOR_BG = 1
    COLOR_PADDLE = 7
    COLOR_BALL = 10
    COLOR_CPU = 8
    COLOR_PARTICLE = 7
    COLOR_ITEM_BG = 14
    COLOR_TRASH = 4
    
    SHAKE_DURATION = 15
    SUPER_SHOT_SPEED_MULT = 2.0

class Particle:
    """エフェクト用パーティクル"""
    def __init__(self, x, y, color, vx=None, vy=None, life=15, kind="SPARK"):
        self.x = x
        self.y = y
        self.vx = vx if vx is not None else pyxel.rndf(-1.5, 1.5)
        self.vy = vy if vy is not None else pyxel.rndf(-1.5, 1.5)
        self.color = color
        self.life = life
        self.kind = kind

    def update(self):
        self.x += self.vx
        self.y += self.vy
        self.life -= 1

    def draw(self):
        if self.kind == "SPARK":
            pyxel.pset(self.x, self.y, self.color)
        elif self.kind == "TRAIL":
            pyxel.circ(self.x, self.y, 1, self.color)
        elif self.kind == "DUST":
            pyxel.rect(self.x, self.y, 1, 1, self.color)

class Button:
    """画面内ボタン"""
    def __init__(self, x, y, w, h, text, color, active_color=9):
        self.x = x
        self.y = y
        self.w = w
        self.h = h
        self.text = text
        self.color = color
        self.active_color = active_color
        self.is_pressed = False
        self.is_enabled = True

    def update(self):
        self.is_pressed = False
        if not self.is_enabled:
            return False
            
        if pyxel.btn(pyxel.MOUSE_BUTTON_LEFT):
            if self.x <= pyxel.mouse_x <= self.x + self.w and \
               self.y <= pyxel.mouse_y <= self.y + self.h:
                self.is_pressed = True
                return True
        return False

    def draw(self):
        col = self.color if self.is_enabled else 5
        if self.is_pressed:
            col = self.active_color
        
        # 必殺技発動可能時の点滅
        if self.is_enabled and "SHOT" in self.text:
            if (pyxel.frame_count // 4) % 2 == 0:
                col = 7 # 白
            
        pyxel.rect(self.x, self.y, self.w, self.h, col)
        pyxel.rectb(self.x, self.y, self.w, self.h, 7)
        
        tx = self.x + (self.w - len(self.text) * 4) // 2
        ty = self.y + (self.h - 6) // 2
        pyxel.text(tx, ty, self.text, 7 if self.is_enabled else 13)

class Item:
    """審判が投げ入れるアイテム"""
    TYPES = {
        "BIG_PADDLE": ["LENGTH+", 11], # 長くなる (Green)
        "BIG_BALL":   ["BALL-D+", 10], # ボール巨大化 (Yellow)
        "TURBO":      ["SPEED+", 9],  # スピードアップ (Cyan)
        "REVERSE":    ["CONFUSE", 12], # 操作反転 (Purple)
    }
    def __init__(self, x, y, kind):
        self.x = x
        self.y = y
        self.kind = kind
        self.display_text, self.icon_color = self.TYPES[kind]
        self.vy = 1.2
        self.life = 300
        self.angle = 0
        # アイテム感を出すために少し大きく(16x16程度)
        self.w = 20
        self.h = 12

    def update(self):
        self.y += self.vy
        if self.y > Config.SCREEN_HEIGHT - 30:
            self.vy = 0
        self.life -= 1
        self.angle += 10

    def draw(self):
        # アイテム感の演出：光の輪（ハロー効果）を大きく
        r = 10 + math.sin(pyxel.frame_count * 0.2) * 3
        pyxel.circb(self.x + self.w//2, self.y + self.h//2, r, (pyxel.frame_count // 2) % 16)
        
        # 本体
        pyxel.rect(self.x, self.y, self.w, self.h, self.icon_color)
        pyxel.rectb(self.x, self.y, self.w, self.h, 7)
        
        # テキスト
        pyxel.text(self.x + 2, self.y + 4, self.display_text, 7)
        
        # 豪華なエフェクト：周囲に破片を回転
        for i in range(3):
            ang = self.angle + i * 120
            px = self.x + self.w//2 + math.cos(math.radians(ang)) * 12
            py = self.y + self.h//2 + math.sin(math.radians(ang)) * 12
            pyxel.pset(px, py, 7)

class Trash:
    """観客が投げるゴミ"""
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.life = 150
        self.vx = pyxel.rndf(-1, 1)
        self.vy = pyxel.rndf(1, 2)

    def update(self):
        self.x += self.vx
        self.y += self.vy
        if self.y > Config.SCREEN_HEIGHT - 5:
            self.vy = 0
            self.vx = 0
        self.life -= 1

    def draw(self):
        pyxel.pset(self.x, self.y, Config.COLOR_TRASH)
        pyxel.pset(self.x+1, self.y, Config.COLOR_TRASH)
        pyxel.pset(self.x, self.y+1, Config.COLOR_TRASH)

class Ball:
    """テニスボールクラス"""
    def __init__(self):
        self.reset()
        self.size = Config.BALL_SIZE
        self.is_ghost = False

    def reset(self, direction=1):
        self.x = Config.SCREEN_WIDTH // 2
        self.y = Config.SCREEN_HEIGHT // 2
        self.vx = 2.0 * direction
        self.vy = pyxel.rndf(-1.5, 1.5)
        self.speed_boost = 1.0
        self.is_super = False
        self.size = Config.BALL_SIZE
        self.is_ghost = False

    def update(self, app):
        if app.wind_power != 0:
            self.vy += app.wind_power
            
        self.x += self.vx * self.speed_boost
        self.y += self.vy * self.speed_boost
        
        if self.y < 0 or self.y > Config.SCREEN_HEIGHT - self.size:
            self.vy *= -1
            app.play_se_bounce()
            app.spawn_particles(self.x, self.y, Config.COLOR_PARTICLE, 3)
            
        if self.is_super:
            if pyxel.frame_count % 2 == 0:
                app.particles.append(Particle(self.x, self.y, 10, 0, 0, 10, "TRAIL"))
            app.shake_amount = max(app.shake_amount, 2)

    def draw(self):
        if self.is_ghost and (pyxel.frame_count // 4) % 2 == 0:
            return
            
        color = Config.COLOR_BALL if not self.is_super else (pyxel.frame_count // 2 % 16)
        pyxel.circ(self.x, self.y, self.size, color)
        if self.is_super:
            pyxel.circb(self.x, self.y, self.size + 1, 7)

class Paddle:
    """パドル（プレイヤー/CPU）"""
    def __init__(self, x, color, is_cpu=False):
        self.x = x
        self.y = Config.SCREEN_HEIGHT // 2 - Config.PADDLE_HEIGHT // 2
        self.color = color
        self.is_cpu = is_cpu
        self.score = 0
        self.gauge = 0
        self.height = Config.PADDLE_HEIGHT
        self.speed = 2.5
        self.is_reversed = False
        self.is_sticky = False
        self.timer_effect = 0

    def update(self, ball, btn_up=False, btn_down=False):
        if self.timer_effect > 0:
            self.timer_effect -= 1
            if self.timer_effect == 0:
                self.reset_effects()

        current_speed = self.speed * 0.5 if self.is_sticky else self.speed
        
        if self.is_cpu:
            target_y = ball.y - self.height // 2
            if abs(self.y - target_y) > 2:
                self.y += 1.5 if self.y < target_y else -1.5
        else:
            up = pyxel.btn(pyxel.KEY_UP) or btn_up
            down = pyxel.btn(pyxel.KEY_DOWN) or btn_down
            
            if self.is_reversed:
                up, down = down, up
                
            if up: self.y -= current_speed
            if down: self.y += current_speed
            
        self.y = max(10, min(Config.SCREEN_HEIGHT - self.height - 10, self.y))

    def reset_effects(self):
        self.height = Config.PADDLE_HEIGHT
        self.speed = 2.5
        self.is_reversed = False
        self.is_sticky = False

    def draw(self):
        pyxel.rect(self.x, self.y, Config.PADDLE_WIDTH, self.height, self.color)
        if not self.is_cpu:
            # 必殺技ゲージ：大きく目立つように中央付近、あるいは下部に配置
            # 今回は画面中央下部に「SUPER GAUGE」として配置
            pass # App.draw で描画

class App:
    def __init__(self):
        # 画面サイズをそのままに、UIパーツを巨大化
        pyxel.init(Config.SCREEN_WIDTH, Config.SCREEN_HEIGHT, title="ULTIMATE CHAOS TENNIS")
        pyxel.mouse(True)
        self.init_assets()
        self.init_buttons()
        self.reset_game()
        pyxel.run(self.update, self.draw)

    def init_buttons(self):
        # レイアウト変更：UP(左端), DOWN(右端), SUPER(下中央)
        # バーを画面奥に寄せるため、ボタンの判定位置も再調整
        self.btn_up = Button(0, 0, 30, Config.SCREEN_HEIGHT, "UP", 1, 1) # 透明
        self.btn_down = Button(Config.SCREEN_WIDTH - 30, 0, 30, Config.SCREEN_HEIGHT, "DWN", 1, 1) # 透明
        self.btn_super = Button(Config.SCREEN_WIDTH // 2 - 25, Config.SCREEN_HEIGHT - 35, 50, 20, "SHOT", 10)

    def reset_game(self):
        self.balls = [Ball()]
        # バーをもう少し奥に（35 -> 15, 145 -> 155）
        self.player = Paddle(15, Config.COLOR_PADDLE)
        self.cpu = Paddle(Config.SCREEN_WIDTH - 15, Config.COLOR_CPU, is_cpu=True)
        self.particles = []
        self.items = []
        self.trashes = []
        self.shake_amount = 0
        self.flash_timer = 0
        self.game_state = "PLAYING"
        self.wind_power = 0
        self.wind_timer = 0
        self.thunder_timer = 0
        self.sticky_zones = []
        pyxel.playm(0, loop=True)

    def init_assets(self):
        pyxel.sounds[0].set("g2r", "p", "7", "v", 5)
        pyxel.sounds[1].set("c3e3g3c4", "n", "7", "v", 10)
        pyxel.sounds[2].set("c2c3c2c3c2c3", "s", "7", "f", 20)
        pyxel.sounds[3].set("e3g3c4e3g4c4", "p", "7", "v", 30)
        pyxel.sounds[10].set("c2e2g2c2 e2g2c3e2 f2a2c3f2 g2b2d3g2", "p", "2", "v", 20)
        pyxel.sounds[11].set("c3e3g3c3 e3g3c4e3 f3a3c4f3 g3b3d4g3", "n", "2", "v", 15)
        pyxel.musics[0].set([10], [11], [], [])

    def update(self):
        if self.game_state == "SCORE":
            if pyxel.frame_count % 30 == 0:
                self.game_state = "PLAYING"
                self.balls = [Ball()]
                self.balls[0].reset(1 if self.balls[0].x < 0 else -1)
                self.player.reset_effects()
                self.cpu.reset_effects()
                self.sticky_zones = []
            return

        if self.shake_amount > 0: self.shake_amount -= 1
        if self.flash_timer > 0: self.flash_timer -= 1
        if self.thunder_timer > 0: self.thunder_timer -= 1

        self.update_events()
        
        # 入力処理：画面端30pxをUP/DOWNに割り当て
        up_active = False
        down_active = False
        if pyxel.btn(pyxel.MOUSE_BUTTON_LEFT):
            if pyxel.mouse_x < 30: up_active = True
            if pyxel.mouse_x > Config.SCREEN_WIDTH - 30: down_active = True

        self.btn_super.is_enabled = (self.player.gauge >= 100)
        super_pressed = self.btn_super.update()
        
        self.player.update(self.balls[0], up_active, down_active)
        self.cpu.update(self.balls[0])

        # ボール更新
        for b in self.balls[:]:
            b.update(self)
            can_hit = not b.is_super
            
            if b.vx < 0 and \
               self.player.x < b.x < self.player.x + Config.PADDLE_WIDTH and \
               self.player.y < b.y < self.player.y + self.player.height:
                if can_hit: self.hit_paddle(self.player, b)
                else: 
                    self.spawn_particles(b.x, b.y, 10, 2)
                    self.shake_amount = 8

            if b.vx > 0 and \
               self.cpu.x < b.x + b.size < self.cpu.x + Config.PADDLE_WIDTH and \
               self.cpu.y < b.y < self.cpu.y + self.cpu.height:
                if can_hit: self.hit_paddle(self.cpu, b)
                else:
                    self.spawn_particles(b.x, b.y, 10, 2)
                    self.shake_amount = 8

            if b.x < 0: self.score_goal(self.cpu, b)
            elif b.x > Config.SCREEN_WIDTH: self.score_goal(self.player, b)

        # アイテム更新
        for i in self.items[:]:
            i.update()
            # 取得判定をさらに緩和 (判定をパドル前方まで広げる)
            if abs(i.x - self.player.x) < 25 and abs(i.y - (self.player.y + self.player.height//2)) < self.player.height//2 + 10:
                self.apply_item(i.kind)
                self.items.remove(i)
            elif i.life <= 0: self.items.remove(i)

        for t in self.trashes[:]:
            t.update()
            if abs(t.x - (self.player.x+2)) < 8 and abs(t.y - (self.player.y + self.player.height//2)) < self.player.height//2:
                self.player.is_sticky = True
            if t.life <= 0: self.trashes.remove(t)

        for p in self.particles[:]:
            p.update()
            if p.life <= 0: self.particles.remove(p)

        if (pyxel.btnp(pyxel.KEY_SPACE) or super_pressed) and self.player.gauge >= 100:
            self.trigger_super_shot()

    def update_events(self):
        # アイテム投下（パドルの位置 15, 145 付近へ）
        if pyxel.frame_count % (30 * 12) == 0:
            kind = random.choice(list(Item.TYPES.keys()))
            target_x = random.choice([25, Config.SCREEN_WIDTH - 45])
            self.items.append(Item(target_x, -15, kind))

        if pyxel.frame_count % (30 * 5) == 0:
            self.trashes.append(Trash(random.randint(40, 120), -10))

        if self.wind_timer > 0:
            self.wind_timer -= 1
            if self.wind_timer == 0: self.wind_power = 0
        elif pyxel.frame_count % (30 * 20) == 0:
            self.wind_power = pyxel.rndf(-0.1, 0.1)
            self.wind_timer = 30 * 5

        if pyxel.frame_count % (30 * 30) == 0:
            self.balls.append(Ball())

        if pyxel.frame_count % (30 * 25) == 0:
            self.thunder_timer = 20
            self.flash_timer = 5
            pyxel.play(3, 2)

        if pyxel.frame_count % (30 * 12) == 0:
            self.sticky_zones = [(random.randint(60, 100), random.randint(20, 100))]

        if pyxel.frame_count % (30 * 10) == 0:
            for b in self.balls: b.is_ghost = not b.is_ghost

    def apply_item(self, kind):
        pyxel.play(3, 1)
        self.player.timer_effect = 30 * 8
        if kind == "BIG_PADDLE": self.player.height = Config.PADDLE_HEIGHT * 2
        elif kind == "BIG_BALL": 
            for b in self.balls: b.size = Config.BALL_SIZE * 3
        elif kind == "TURBO": self.player.speed = 4.5
        elif kind == "REVERSE":
            self.player.is_reversed = True

    def trigger_super_shot(self):
        self.player.gauge = 0
        for b in self.balls:
            b.is_super = True
            b.speed_boost = Config.SUPER_SHOT_SPEED_MULT
        self.shake_amount = 30
        pyxel.play(3, 2)

    def hit_paddle(self, paddle, ball):
        ball.vx *= -1.1
        ball.vx = max(-5, min(5, ball.vx))
        hit_pos = (ball.y - paddle.y) / paddle.height
        ball.vy = (hit_pos - 0.5) * 4
        if ball.is_super:
            ball.is_super = False
            ball.speed_boost = 1.0
        pyxel.play(3, 1)
        self.spawn_particles(ball.x, ball.y, paddle.color, 8)
        if not paddle.is_cpu:
            paddle.gauge = min(100, paddle.gauge + 15) # ゲージ増加量を少し増やした

    def score_goal(self, winner, ball):
        winner.score += 1
        self.game_state = "SCORE"
        self.flash_timer = 5
        pyxel.play(3, 3)
        self.spawn_particles(ball.x, ball.y, 7, 30)

    def spawn_particles(self, x, y, color, count):
        for _ in range(count):
            self.particles.append(Particle(x, y, color))

    def play_se_bounce(self):
        pyxel.play(3, 0)

    def draw(self):
        ox = pyxel.rndf(-self.shake_amount, self.shake_amount) if self.shake_amount > 0 else 0
        oy = pyxel.rndf(-self.shake_amount, self.shake_amount) if self.shake_amount > 0 else 0
        
        pyxel.cls(1)
        if self.flash_timer > 0: pyxel.cls(7)
        pyxel.camera(ox, oy)
        
        # フィールド
        pyxel.rect(0, 0, Config.SCREEN_WIDTH, 5, 13)
        pyxel.rect(0, Config.SCREEN_HEIGHT - 40, Config.SCREEN_WIDTH, 40, 0) # UI下部エリア
        
        for y in range(0, 80, 10):
            pyxel.rect(Config.SCREEN_WIDTH // 2, y, 1, 5, 5)
        
        for i in self.items: i.draw()
        for t in self.trashes: t.draw()
        for z in self.sticky_zones: pyxel.rect(z[0], z[1], 20, 20, 4)

        self.player.draw()
        self.cpu.draw()
        for b in self.balls: b.draw()
        for p in self.particles: p.draw()
        
        # 必殺技ゲージ（UI下部エリアに大きく表示）
        gx, gy = 40, Config.SCREEN_HEIGHT - 12
        pyxel.text(gx - 35, gy, "SPECIAL:", 7)
        pyxel.rect(gx, gy, 80, 6, 1)
        pyxel.rect(gx + 1, gy + 1, (self.player.gauge / 100) * 78, 4, 10 if self.player.gauge < 100 else 9)
        if self.player.gauge >= 100:
            pyxel.text(gx + 25, gy - 8, "!!! READY !!!", (pyxel.frame_count // 3) % 16)

        # スコア
        pyxel.text(Config.SCREEN_WIDTH // 2 - 20, 10, f"YOU: {self.player.score}", 7)
        pyxel.text(Config.SCREEN_WIDTH // 2 + 5, 10, f"CPU: {self.cpu.score}", 7)

        # 操作説明
        pyxel.text(5, Config.SCREEN_HEIGHT - 35, "<- UP", 13)
        pyxel.text(Config.SCREEN_WIDTH - 25, Config.SCREEN_HEIGHT - 35, "DWN ->", 13)
        
        self.btn_super.draw()

        if self.game_state == "SCORE":
            pyxel.text(Config.SCREEN_WIDTH // 2 - 15, Config.SCREEN_HEIGHT // 2, "GOAL!!", (pyxel.frame_count // 2) % 16)
        
        if self.thunder_timer > 0: pyxel.cls(10)
        pyxel.camera()

if __name__ == "__main__":
    App()
