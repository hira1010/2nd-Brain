<#
.SYNOPSIS
    Unified Manga Prompt Manager (4-Page Edition) - Flat Logic
#>

[CmdletBinding(SupportsShouldProcess = $true)]
param (
    [Parameter(Position = 0)]
    [ValidateSet("All", "Update", "Cleanup")]
    [string]$Mode = "All"
)

$ErrorActionPreference = "Stop"
$ScriptDir = $PSScriptRoot
$JsonPath = Join-Path $ScriptDir "prompt_data.json"
$ParentDir = (Get-Item (Join-Path $ScriptDir "..")).FullName

if (-not (Test-Path $JsonPath)) { Throw "Config not found." }

$jsonContent = [System.IO.File]::ReadAllText($JsonPath, [System.Text.Encoding]::UTF8)
$Config = $jsonContent | ConvertFrom-Json

Write-Host "=== MANGA PROMPT MANAGER (FINAL) ===" -ForegroundColor Cyan
Write-Host "Target: $ParentDir"

$files = Get-ChildItem -Path $ParentDir -Recurse -Filter "No*_*.md"

foreach ($file in $files) {
    try {
        # --- READ FILE ---
        $path = $file.FullName
        $content = [System.IO.File]::ReadAllText($path, [System.Text.Encoding]::UTF8)
        $original = $content

        # --- UPDATE MODE ---
        if ($Mode -match "All|Update") {
            # Metadata Extraction
            $no = 1
            if ($content -match '\| No \| (\d+) \|') { $no = [int]$Matches[1] }
            
            $title = "Investment"
            if ($content -match $Config.TitleRegex) { $title = $Matches[1].Trim() }
            
            $desc = "Understanding"
            if ($content -match $Config.DescRegex) { $desc = $Matches[1].Trim() }

            # Strategy
            $isSpiritual = ($no % 3 -eq 0)
            if ($isSpiritual) {
                $tpls = @($Config.TemplateSpiritualP1, $Config.TemplateSpiritualP2, $Config.TemplateSpiritualP3, $Config.TemplateSpiritualP4)
                $yutoReact = "" 
            }
            else {
                $tpls = @($Config.TemplateNormalP1, $Config.TemplateNormalP2, $Config.TemplateNormalP3, $Config.TemplateNormalP4)
                $yutoReact = $Config.ReactTemplate -f $desc
            }

            # Generate Pages
            $pages = @()
            for ($i = 0; $i -lt 4; $i++) {
                $raw = $tpls[$i].Replace("{Title}", $title).Replace("{Desc}", $desc).Replace("{YutoReact}", $yutoReact).Replace("{AnatomyBlock}", $Config.Anatomy).Replace("{Remi}", $Config.Remi).Replace("{Yuto}", $Config.Yuto)
                $final = $Config.Prefix + "`n`n" + $raw
                $pages += $final.Replace('$', '$$')
            }

            # Apply Regex for P1/P2
            $opt = [System.Text.RegularExpressions.RegexOptions]::Singleline
            $content = [regex]::Replace($content, "(## .*?1.*?\n\s*``````text\s*\n).*?(\n``````)", ('$1' + $pages[0] + '$2'), $opt)
            $content = [regex]::Replace($content, "(## .*?2.*?\n\s*``````text\s*\n).*?(\n``````)", ('$1' + $pages[1] + '$2'), $opt)

            # Insert/Update P3
            if ($content -match "## .*?3.*?") {
                $content = [regex]::Replace($content, "(## .*?3.*?\n\s*``````text\s*\n).*?(\n``````)", ('$1' + $pages[2] + '$2'), $opt)
            }
            elseif ($content -match "## .*?2.*?``````\s*") {
                $k = [regex]::Match($content, "(## .*?2.*?\n\s*``````text\s*\n.*?``````)", $opt)
                if ($k.Success) {
                    $blk = "`n`n## 3 page prompt`n`n```text`n" + $pages[2].Replace('$$', '$') + "`n```"
                    $content = $content.Replace($k.Value, $k.Value + $blk)
                }
            }

            # Insert/Update P4
            if ($content -match "## .*?4.*?") {
                    $content = [regex]::Replace($content, "(## .*?4.*?\n\s*``````text\s*\n).*?(\n``````)", ('$1' + $pages[3] + '$2'), $opt)
                }
                elseif ($content -match "## .*?3.*?``````\s*") {
                    $k = [regex]::Match($content, "(## .*?3.*?\n\s*``````text\s*\n.*?``````)", $opt)
                    if ($k.Success) {
                        $blk = "`n`n## 4 page prompt`n`n```text`n" + $pages[3].Replace('$$', '$') + "`n```"
                    $content = $content.Replace($k.Value, $k.Value + $blk)
                }
            }
        }

        # --- CLEANUP MODE ---
        if ($Mode -match "All | Cleanup") {
            $period = [string][char]0x3002
            $double = $period + $period
            if ($content.Contains($double)) {
                $content = $content.Replace($double, $period)
            }
        }

        # --- SAVE ---
        if ($content -ne $original) {
            if ($PSCmdlet.ShouldProcess($file.Name, "Save Changes")) {
                [System.IO.File]::WriteAllText($path, $content, [System.Text.Encoding]::UTF8)
                Write-Host "Updated: $($file.Name)" -ForegroundColor Green
            }
        }

    } catch {
        Write-Warning "Error processing $($file.Name): $($_.Exception.Message)"
    }
}

Write-Host "Done." -ForegroundColor Green
