
$JsonPath = "$PSScriptRoot\prompt_data.json"
$Config = Get-Content $JsonPath -Raw | ConvertFrom-Json
$ParentDir = (Get-Item "$PSScriptRoot\..").FullName
$Files = Get-ChildItem -Path $ParentDir -Recurse -Filter "No*_*.md"

foreach ($f in $Files) {
    $c = Get-Content $f.FullName -Raw
    $original = $c
    
    # Extract Metadata
    $no = 1
    if ($c -match '\| No \| (\d+) \|') { $no = [int]$Matches[1] }
    $title = "Invest"
    if ($c -match $Config.TitleRegex) { $title = $Matches[1].Trim() }
    $desc = "Desc"
    if ($c -match $Config.DescRegex) { $desc = $Matches[1].Trim() }
    
    # Strategy
    $isSpiritual = ($no % 3 -eq 0)
    $tpls = if ($isSpiritual) { @($Config.TemplateSpiritualP1, $Config.TemplateSpiritualP2, $Config.TemplateSpiritualP3, $Config.TemplateSpiritualP4) } else { @($Config.TemplateNormalP1, $Config.TemplateNormalP2, $Config.TemplateNormalP3, $Config.TemplateNormalP4) }
    $react = if ($isSpiritual) { "" } else { $Config.ReactTemplate -f $desc }
    
    # Pages
    $pages = @()
    foreach ($t in $tpls) {
        $p = $t.Replace("{Title}", $title).Replace("{Desc}", $desc).Replace("{YutoReact}", $react).Replace("{AnatomyBlock}", $Config.Anatomy).Replace("{Remi}", $Config.Remi).Replace("{Yuto}", $Config.Yuto)
        $pages += ($Config.Prefix + "`n`n" + $p).Replace('$', '$$')
    }
    
    # Replace P1/P2
    $opt = [System.Text.RegularExpressions.RegexOptions]::Singleline
    $c = [regex]::Replace($c, "(## .*?1.*?\n\s*``````text\s*\n).*?(\n``````)", ('$1' + $pages[0] + '$2'), $opt)
    $c = [regex]::Replace($c, "(## .*?2.*?\n\s*``````text\s*\n).*?(\n``````)", ('$1' + $pages[1] + '$2'), $opt)
    
    # P3
    if ($c -match "## .*?3.*?") {
        $c = [regex]::Replace($c, "(## .*?3.*?\n\s*``````text\s*\n).*?(\n``````)", ('$1' + $pages[2] + '$2'), $opt)
    }
    else {
        if ($c -match "## .*?2.*?``````\s*") {
            $m = [regex]::Match($c, "(## .*?2.*?\n\s*``````text\s*\n.*?``````)", $opt)
            if ($m.Success) {
                $c = $c.Replace($m.Value, $m.Value + "`n`n## 3 page prompt`n`n```text`n" + $pages[2].Replace('$$', '$') + "`n```") }
        }
    }
    
    # P4
    if ($c -match "## .*?4.*?") {
                    $c = [regex]::Replace($c, "(## .*?4.*?\n\s*``````text\s*\n).*?(\n``````)", ('$1' + $pages[3] + '$2'), $opt)
                }
                else {
                    if ($c -match "## .*?3.*?``````\s*") {
                        $m = [regex]::Match($c, "(## .*?3.*?\n\s*``````text\s*\n.*?``````)", $opt)
                        if ($m.Success) {
                            $c = $c.Replace($m.Value, $m.Value + "`n`n## 4 page prompt`n`n```text`n" + $pages[3].Replace('$$', '$') + "`n```") }
        }
    }
    
    if ($c -ne $original) {
        Set-Content $f.FullName $c -Encoding UTF8
        Write-Host "Updated: $($f.Name)"
    }
}
