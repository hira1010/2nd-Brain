﻿# Settings.ps1 - レミ投資漫画 共通設定
# このファイルは UTF-8 (with BOM) で保存ください。

$Config = @{
    # ディレクトリパス
    Paths      = @{
        BaseDir    = "c:\Users\hirak\Desktop\2nd-Brain\18_レミ投資漫画"
        ConfigDir  = "c:\Users\hirak\Desktop\2nd-Brain\18_レミ投資漫画\05_設定"
        ContentDir = "c:\Users\hirak\Desktop\2nd-Brain\18_レミ投資漫画" # 広めに設定
    }

    # キャラクター定義 (Unified)
    Characters = @{
        Remi = "Remi: (SIGNATURE OUTFIT: Always wearing a Tailored RED blazer over a Black lace top, no variations allowed). (Silky SILVER hair:1.5), (Vibrant RED eyes:1.4). NO GLOVES."
        Yuto = "Yuto: Short Black hair, (Traditional Black GAKURAN school uniform:1.4), Gold buttons. Energetic learner. BARE HANDS (no gloves)."
    }

    # 解剖学的要件 (Unified)
    AnatomyBlock = "### Character Anatomy:`n- HANDS/FINGERS: MUST be drawing with 5 fingers. Knuckles and joints must be anatomically correct. NO deformities.`n- EYES: Symmetrical, properly aligned. Clear pupils.`n- FACE: Proportionate features, clean jawline. NO distorted faces.`n- BODY: Natural pose and anatomy. Arms and legs must have correct length and joints."

    # プロンプトテンプレート
    Prompts    = @{
        Prefix = "Create a SINGLE-PAGE vertical Japanese manga illustration. CRITICAL: Output must be PORTRAIT orientation, TALL format (aspect ratio 1200:1697). This is ONE page only, not multiple pages combined."

        # === パターンA: 通常 (Normal) ===
        # 解説({Desc})を受け、優斗が具体的に納得する
        Normal = @{
            P1 = "### Technical Setup:`n- Aspect Ratio: 1200:1697 (Portrait)`n- Resolution: High quality manga illustration`n`n{AnatomyBlock}`n`n### Character Settings:`n- {Remi}`n- {Yuto}`n`n### PAGE 1 VERTICAL LAYOUT (1200w x 1697h)`nTop 40%: Modern office. Remi stands beside holographic display showing `"{Title}`" in Japanese. Yuto looks curious. Speech bubble (Remi): `"優斗君、今日は『{Title}』について教えるわよ。`" Title box: Black slender box with white Japanese text `"{Title}`" placed in the bottom-right corner.`nMiddle 30%: Yuto responds eagerly: `"はい！もっと詳しく知りたいです！`" Then Remi explains with SYMBOLIC METAPHOR visual - LEFT: chaos/confusion labeled `"混乱`" in cold dark tones. RIGHT: order/wisdom labeled `"{Title}`" in golden warm tones. Remi points to golden side. Speech bubble (Remi): `"いい心がけね。でも、ただ知るだけじゃ意味がないわ。つまり、{Desc}。`"`nBottom 30%: Panel 3 right - Yuto looking thoughtful: `"{YutoReact}`". Panel 4 left - Remi's side profile, gentle smile.`n`n### Art Style:`nJapanese manga, cel shaded, vibrant colors. Characters MUST match descriptions exactly. NO GLOVES."
            
            P2 = "### Technical Setup:`n- Aspect Ratio: 1200:1697 (Portrait)`n- Resolution: High quality manga illustration`n`n{AnatomyBlock}`n`n### Character Settings:`n- {Remi}`n- {Yuto}`n`n### PAGE 2 VERTICAL LAYOUT (1200w x 1697h)`nTop 40%: Close-up of Remi holding glowing golden sphere (symbolizing '{Title}'), face illuminated, wise expression. Speech bubble (Remi): `"{Desc}。 これが投資の本質よ。しっかり頭に叩き込みなさい。`"`nMiddle 30%: Remi in split-world. LEFT: dark storm/chaos (purple/red). RIGHT: golden garden/peace (representing '{Title}'). She points to golden side decisively.`nBottom 30%: Panel 3 right - Yuto with golden bubbles showing happy future. Panel 4 left - Yuto enlightened. Speech bubble: `"そうか…{Title}の本質はここにあったんですね。`" Remi watching warmly (no speech).`n`n### Art Style:`nCinematic lighting, Gold/Purple theme. NO GLOVES."
        }

        # === パターンB: スピリチュアル (Spiritual) ===
        # 解説({Desc})を受け、レミが宇宙的飛躍をし、優斗が心でツッコミを入れる
        # 3の倍数のファイルに適用
        Spiritual = @{
            P1 = "### Technical Setup:`n- Aspect Ratio: 1200:1697 (Portrait)`n- Resolution: High quality manga illustration`n`n{AnatomyBlock}`n`n### Character Settings:`n- {Remi}`n- {Yuto}`n`n### PAGE 1 VERTICAL LAYOUT (1200w x 1697h)`nTop 40%: Modern office. Remi stands beside holographic display showing `"{Title}`" in Japanese. Yuto looks curious. Speech bubble (Remi): `"優斗君、今日は『{Title}』について教えるわよ。`" Title box: Black slender box with white Japanese text `"{Title}`" placed in the bottom-right corner.`nMiddle 30%: Yuto responds eagerly: `"はい！もっと詳しく知りたいです！`" Then Remi explains with SYMBOLIC METAPHOR visual - LEFT: chaos. RIGHT: COSMIC GALAXY labeled `"{Title}`" in mystic tones. Remi spreads arms. Speech bubble (Remi): `"波動を感じて。{Desc}。これは宇宙の采配なのよ。`"`nBottom 30%: Panel 3 right - Yuto looking confused/overwhelmed (sweat drop): `"(で、出た…レミさんのスピリチュアル解説…)"` (Thought bubble). Panel 4 left - Remi's side profile, ecstatic smile.`n`n### Art Style:`nJapanese manga, cel shaded, vibrant colors. Characters MUST match descriptions exactly. NO GLOVES."

            P2 = "### Technical Setup:`n- Aspect Ratio: 1200:1697 (Portrait)`n- Resolution: High quality manga illustration`n`n{AnatomyBlock}`n`n### Character Settings:`n- {Remi}`n- {Yuto}`n`n### PAGE 2 VERTICAL LAYOUT (1200w x 1697h)`nTop 40%: Close-up of Remi levitating glowing golden sphere (symbolizing '{Title}'), background is STARRY UNIVERSE. Speech bubble (Remi): `"{Desc}。 魂のステージを上げるのよ！`"`nMiddle 30%: Remi in split-world. LEFT: dull grey world. RIGHT: ASCENSION LIGHT (representing '{Title}'). She points to light.`nBottom 30%: Panel 3 right - Yuto enveloped in light, looking blank but impressed: `"よ、よく分からないけど凄いことは分かりました！`" Panel 4 left - Remi satisfied nod.`n`n### Art Style:`nCinematic lighting, Gold/Purple/Cosmic theme. NO GLOVES."
        }
    }

    # 画像設定
    Image      = @{
        Width       = 1200
        Height      = 1697
        AspectRatio = "1200:1697"
    }
}

