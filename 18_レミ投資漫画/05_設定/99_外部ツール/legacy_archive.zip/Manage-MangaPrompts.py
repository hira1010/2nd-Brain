import os
import json
import re
import argparse
import sys

# Constants
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
JSON_PATH = os.path.join(SCRIPT_DIR, "prompt_data.json")
PARENT_DIR = os.path.dirname(SCRIPT_DIR)

def load_config():
    if not os.path.exists(JSON_PATH):
        print(f"Error: Config not found at {JSON_PATH}")
        sys.exit(1)
    
    with open(JSON_PATH, "r", encoding="utf-8") as f:
        return json.load(f)

def generate_pages(config, title, desc, yuto_react, is_spiritual):
    if is_spiritual:
        tpls = [
            config["TemplateSpiritualP1"],
            config["TemplateSpiritualP2"],
            config["TemplateSpiritualP3"],
            config["TemplateSpiritualP4"]
        ]
        local_react = ""
    else:
        tpls = [
            config["TemplateNormalP1"],
            config["TemplateNormalP2"],
            config["TemplateNormalP3"],
            config["TemplateNormalP4"]
        ]
        local_react = yuto_react

    pages = []
    for tpl in tpls:
        content = tpl.replace("{Title}", title)\
                     .replace("{Desc}", desc)\
                     .replace("{YutoReact}", local_react)\
                     .replace("{AnatomyBlock}", config["Anatomy"])\
                     .replace("{Remi}", config["Remi"])\
                     .replace("{Yuto}", config["Yuto"])
        
        full_page = f"{config['Prefix']}\n\n{content}"
        pages.append(full_page)
    
    return pages

def find_files(root_dir):
    matches = []
    for root, dirs, files in os.walk(root_dir):
        for file in files:
            if file.startswith("No") and file.endswith(".md"):
                matches.append(os.path.join(root, file))
    return matches

def update_file(file_path, config, mode):
    content = ""
    encoding_used = "utf-8"
    try:
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                content = oniginal_content = f.read()
        except UnicodeDecodeError:
            encoding_used = "cp932"
            with open(file_path, "r", encoding="cp932") as f:
                content = oniginal_content = f.read()

        # Extract No, Title, Desc
        no = 1
        no_match = re.search(r'\| No \| (\d+) \|', content)
        if no_match:
            no = int(no_match.group(1))

        title = "Investment"
        title_match = re.search(config["TitleRegex"], content)
        if title_match:
            title = title_match.group(1).strip()
        
        desc = "Understanding"
        desc_match = re.search(config["DescRegex"], content)
        if desc_match:
            desc = desc_match.group(1).strip()
        
        # Strategy
        is_spiritual = (no % 3 == 0)
        yuto_react_template = config.get("ReactTemplate", "I see... {0}")
        yuto_react = yuto_react_template.format(desc)

        pages = generate_pages(config, title, desc, yuto_react, is_spiritual)

        # Regex Update
        # P1
        content = re.sub(r"(## .*?1.*?\n\s*``````text\s*\n).*?(\n``````)", 
                         lambda m: f"{m.group(1)}{pages[0]}{m.group(2)}", content, flags=re.DOTALL)
        # P2
        content = re.sub(r"(## .*?2.*?\n\s*``````text\s*\n).*?(\n``````)", 
                         lambda m: f"{m.group(1)}{pages[1]}{m.group(2)}", content, flags=re.DOTALL)

        # P3
        if re.search(r"## .*?3.*?", content):
            content = re.sub(r"(## .*?3.*?\n\s*``````text\s*\n).*?(\n``````)", 
                             lambda m: f"{m.group(1)}{pages[2]}{m.group(2)}", content, flags=re.DOTALL)
        else:
            # Append if missing
            matches = list(re.finditer(r"(## .*?2.*?\n\s*``````text\s*\n.*?``````)", content, flags=re.DOTALL))
            if matches:
                last_match = matches[-1]
                blk = f"\n\n## 3 page prompt\n\n```text\n{pages[2]}\n```"
                # Insert after P2 block
                start, end = last_match.span()
                content = content[:end] + blk + content[end:]
        
        # P4
        if re.search(r"## .*?4.*?", content):
            content = re.sub(r"(## .*?4.*?\n\s*``````text\s*\n).*?(\n``````)", 
                             lambda m: f"{m.group(1)}{pages[3]}{m.group(2)}", content, flags=re.DOTALL)
        else:
            # Append if missing (check P3 now)
            matches = list(re.finditer(r"(## .*?3.*?\n\s*``````text\s*\n.*?``````)", content, flags=re.DOTALL))
            if matches:
                last_match = matches[-1]
                blk = f"\n\n## 4 page prompt\n\n```text\n{pages[3]}\n```"
                start, end = last_match.span()
                content = content[:end] + blk + content[end:]

        # Cleanup Mode
        if mode in ["All", "Cleanup"]:
            double_period = "。。"
            if double_period in content:
                content = content.replace(double_period, "。")

        # Save
        if content != oniginal_content:
            with open(file_path, "w", encoding="utf-8") as f:
                f.write(content)
            print(f"Updated: {os.path.basename(file_path)}")
        
    except Exception as e:
        print(f"Failed {os.path.basename(file_path)}: {e}")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", default="All", choices=["All", "Update", "Cleanup"])
    args = parser.parse_args()

    # Force UTF-8 for stdout to prevent print crashes
    sys.stdout.reconfigure(encoding='utf-8')

    print("=== PROMPT MANAGER (PYTHON) ===")
    config = load_config()
    files = find_files(PARENT_DIR)

    if not files:
        print("No files found.")
        return

    for f in files:
        update_file(f, config, args.mode)

    print("Done.")

if __name__ == "__main__":
    main()

def update_file(file_path, config, mode):
    content = ""
    try:
        # Try UTF-8 First
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                content = oniginal_content = f.read()
        except UnicodeDecodeError:
            # Fallback to CP932 with replace to prevent crash
            with open(file_path, "r", encoding="cp932", errors="replace") as f:
                content = oniginal_content = f.read()

        # Extract No, Title, Desc
