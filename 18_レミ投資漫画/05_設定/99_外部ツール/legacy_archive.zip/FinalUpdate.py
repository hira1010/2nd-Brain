import os
import json
import re

# No printing to avoid console encoding issues
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
JSON_PATH = os.path.join(SCRIPT_DIR, "prompt_data.json")
PARENT_DIR = os.path.dirname(SCRIPT_DIR)

def load_config():
    with open(JSON_PATH, "r", encoding="utf-8") as f:
        return json.load(f)

def generate_pages(config, title, desc, yuto_react, is_spiritual):
    if is_spiritual:
        tpls = [config["TemplateSpiritualP1"], config["TemplateSpiritualP2"], config["TemplateSpiritualP3"], config["TemplateSpiritualP4"]]
        local_react = ""
    else:
        tpls = [config["TemplateNormalP1"], config["TemplateNormalP2"], config["TemplateNormalP3"], config["TemplateNormalP4"]]
        local_react = yuto_react

    pages = []
    for tpl in tpls:
        content = tpl.replace("{Title}", title)\
                     .replace("{Desc}", desc)\
                     .replace("{YutoReact}", local_react)\
                     .replace("{AnatomyBlock}", config["Anatomy"])\
                     .replace("{Remi}", config["Remi"])\
                     .replace("{Yuto}", config["Yuto"])
        pages.append(f"{config['Prefix']}\n\n{content}")
    return pages

def main():
    try:
        config = load_config()
    except:
        return

    for root, dirs, files in os.walk(PARENT_DIR):
        for file in files:
            if file.startswith("No") and file.endswith(".md"):
                fpath = os.path.join(root, file)
                try:
                    content = ""
                    try:
                        with open(fpath, "r", encoding="utf-8") as f: content = f.read()
                    except:
                        with open(fpath, "r", encoding="cp932", errors="ignore") as f: content = f.read()
                    
                    original = content
                    
                    no_m = re.search(r'\| No \| (\d+) \|', content)
                    no = int(no_m.group(1)) if no_m else 1
                    
                    title_m = re.search(config["TitleRegex"], content)
                    title = title_m.group(1).strip() if title_m else "Invest"
                    
                    desc_m = re.search(config["DescRegex"], content)
                    desc = desc_m.group(1).strip() if desc_m else "Desc"
                    
                    is_spir = (no % 3 == 0)
                    react = config.get("ReactTemplate", "{0}").format(desc)
                    pages = generate_pages(config, title, desc, react, is_spir)
                    
                    content = re.sub(r"(## .*?1.*?\n\s*``````text\s*\n).*?(\n``````)", lambda m: f"{m.group(1)}{pages[0]}{m.group(2)}", content, flags=re.DOTALL)
                    content = re.sub(r"(## .*?2.*?\n\s*``````text\s*\n).*?(\n``````)", lambda m: f"{m.group(1)}{pages[1]}{m.group(2)}", content, flags=re.DOTALL)
                    
                    if re.search(r"## .*?3.*?", content):
                         content = re.sub(r"(## .*?3.*?\n\s*``````text\s*\n).*?(\n``````)", lambda m: f"{m.group(1)}{pages[2]}{m.group(2)}", content, flags=re.DOTALL)
                    else:
                        ms = list(re.finditer(r"(## .*?2.*?\n\s*``````text\s*\n.*?``````)", content, flags=re.DOTALL))
                        if ms:
                            last = ms[-1]
                            blk = f"\n\n## 3 page prompt\n\n```text\n{pages[2]}\n```"
                            content = content[:last.end()] + blk + content[last.end():]

                    if re.search(r"## .*?4.*?", content):
                         content = re.sub(r"(## .*?4.*?\n\s*``````text\s*\n).*?(\n``````)", lambda m: f"{m.group(1)}{pages[3]}{m.group(2)}", content, flags=re.DOTALL)
                    else:
                        ms = list(re.finditer(r"(## .*?3.*?\n\s*``````text\s*\n.*?``````)", content, flags=re.DOTALL))
                        if ms:
                            last = ms[-1]
                            blk = f"\n\n## 4 page prompt\n\n```text\n{pages[3]}\n```"
                            content = content[:last.end()] + blk + content[last.end():]
                            
                    if content != original:
                        with open(fpath, "w", encoding="utf-8") as f: f.write(content)
                except:
                    pass

if __name__ == "__main__":
    main()
